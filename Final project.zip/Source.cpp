﻿#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "shader.h"
#include "camera.h"
#include <iostream>

#include "cylinder.h"

#include "Sphere.h"

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

void framebuffer_size_callback(GLFWwindow* window, int width, int height);
void mouse_callback(GLFWwindow* window, double xpos, double ypos);
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset);
void processInput(GLFWwindow* window);

// settings
const unsigned int SCR_WIDTH = 800;
const unsigned int SCR_HEIGHT = 600;


struct GLMesh
{
	GLuint vao;         // Handle for the vertex array object
	GLuint vbo;         // Handle for the vertex buffer object
	GLuint nVertices;    // Number of indices of the mesh
};


// Shader programs
GLuint gCubeProgramId;
GLuint gLampProgramId;

// camera
glm::vec3 cameraPos = glm::vec3(0.0f, 0.0f, 3.0f);
glm::vec3 cameraFront = glm::vec3(0.0f, 0.0f, -1.0f);
glm::vec3 cameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

// timing
float gDeltaTime = 0.0f; // time between current frame and last frame
float gLastFrame = 0.0f;

bool firstMouse = true;
float yaw = -90.0f;	// yaw is initialized to -90.0 degrees since a yaw of 0.0 results in a direction vector pointing to the right so we initially rotate a bit to the left.
float pitch = 0.0f;
float lastX = 800.0f / 2.0;
float lastY = 600.0 / 2.0;
float fov = 45.0f;

// timing
float deltaTime = 0.0f;	// time between current frame and last frame
float lastFrame = 0.0f;

// Subject position and scale
glm::vec3 gCubePosition(0.0f, 0.0f, 0.0f);
glm::vec3 gCubeScale(2.0f);

// Cube and light color
//m::vec3 gObjectColor(0.6f, 0.5f, 0.75f);
glm::vec3 gObjectColor(1.f, 0.2f, 0.0f);
glm::vec3 gLightColor(1.0f, 1.0f, 1.0f);

// Light position and scale
glm::vec3 gLightPosition(1.5f, 0.5f, 3.0f);
glm::vec3 gLightScale(0.3f);

// Lamp animation
bool gIsLampOrbiting = true;

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);


/* Cube Vertex Shader Source Code*/
const GLchar* cubeVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
layout(location = 1) in vec3 normal; // VAP position 1 for normals
layout(location = 2) in vec2 textureCoordinate;

out vec3 vertexNormal; // For outgoing normals to fragment shader
out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
out vec2 vertexTextureCoordinate;

//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

	vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

	vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
	vertexTextureCoordinate = textureCoordinate;
}
);

/* Cube Fragment Shader Source Code*/
const GLchar* cubeFragmentShaderSource = GLSL(440,

	in vec3 vertexNormal; // For incoming normals
in vec3 vertexFragmentPos; // For incoming fragment position
in vec2 vertexTextureCoordinate;

out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / Global variables for object color, light color, light position, and camera/view position
uniform vec3 objectColor;
uniform vec3 lightColor;
uniform vec3 lightPos;
uniform vec3 viewPosition;
uniform sampler2D uTexture; // Useful when working with multiple textures
uniform vec2 uvScale;

void main()
{
	/*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

	//Calculate Ambient lighting*/
	float ambientStrength = 0.1f; // Set ambient or global lighting strength
	vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

	//Calculate Diffuse lighting*/
	vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
	vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
	float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
	vec3 diffuse = impact * lightColor; // Generate diffuse light color

	//Calculate Specular lighting*/
	float specularIntensity = 0.8f; // Set specular light strength
	float highlightSize = 16.0f; // Set specular highlight size
	vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
	vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
	//Calculate specular component
	float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
	vec3 specular = specularIntensity * specularComponent * lightColor;

	// Texture holds the color to be used for all three components
	vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

	// Calculate phong result
	vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

	fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
);

/* Lamp Shader Source Code*/
const GLchar* lampVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

		//Uniform / Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);


/* Fragment Shader Source Code*/
const GLchar* lampFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()

{
	fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
);

int main(int argc, char* argv[])
{
	// Create the shader programs
	if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCubeProgramId))
		return EXIT_FAILURE;

	if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gLampProgramId))
		return EXIT_FAILURE;

	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	glUseProgram(gCubeProgramId);
	// We set the texture as texture unit 0
	glUniform1i(glGetUniformLocation(gCubeProgramId, "uTexture"), 0);

	// Sets the background color of the window to black (it will be implicitely used by glClear)
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	
	// Release shader programs
	UDestroyShaderProgram(gCubeProgramId);
	UDestroyShaderProgram(gLampProgramId);

	exit(EXIT_SUCCESS); // Terminates the program successfully
}



int main()
{
	// glfw: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	

	// glfw window creation
	// --------------------
	GLFWwindow* window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "Multiple Objects and Textures", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);
	glfwSetCursorPosCallback(window, mouse_callback);
	glfwSetScrollCallback(window, scroll_callback);


	// tell GLFW to capture our mouse
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// glad: load all OpenGL function pointers
	// ---------------------------------------
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	// Pause and resume lamp orbiting
	static bool isLKeyDown = false;
	if (glfwGetKey(window, GLFW_KEY_L) == GLFW_PRESS && !gIsLampOrbiting)
		gIsLampOrbiting = true;
	else if (glfwGetKey(window, GLFW_KEY_K) == GLFW_PRESS && gIsLampOrbiting)
		gIsLampOrbiting = false;


	// configure global opengl state
	// -----------------------------
	glEnable(GL_DEPTH_TEST);

	// build and compile our shader zprogram
	// ------------------------------------
	Shader ourShader("shaderfiles/7.3.camera.vs", "shaderfiles/7.3.camera.fs");




	// set up vertex data (and buffer(s)) and configure vertex attributes
	// ------------------------------------------------------------------
	float vertices[] = {

		//2D plane
		-8.0f, -1.5f, -8.0f,  0.0f, 0.0f,
		 10.0f, -1.5f, -8.0f,  1.0f, 0.0f,
		 10.0f, -1.5f,  8.0f,  1.0f, 1.0f,
		 10.0f, -1.5f,  8.0f,  1.0f, 1.0f,
		-8.0f, -1.5f,  8.0f,  0.0f, 1.0f,
		-8.0f, -1.5f, -8.0f,  0.0f, 0.0f,

		//cube one back
		-0.25f, -0.5f, -0.5f,  0.0f, 0.0f,
		 0.75f, -0.5f, -0.5f,  1.0f, 0.0f,
		 0.75f,  0.5f, -0.5f,  1.0f, 1.0f,
		 0.75f,  0.5f, -0.5f,  1.0f, 1.0f,
		-0.25f,  0.5f, -0.5f,  0.0f, 1.0f,
		-0.25f, -0.5f, -0.5f,  0.0f, 0.0f,

		//cube one front
		-0.25f, -0.5f,  0.5f,  0.0f, 0.0f,
		 0.75f, -0.5f,  0.5f,  1.0f, 0.0f,
		 0.75f,  0.5f,  0.5f,  1.0f, 1.0f,
		 0.75f,  0.5f,  0.5f,  1.0f, 1.0f,
		-0.25f,  0.5f,  0.5f,  0.0f, 1.0f,
		-0.25f, -0.5f,  0.5f,  0.0f, 0.0f,
	
		//cube one left
		-0.25f,  0.5f,  0.5f,  1.0f, 0.0f,
		-0.25f,  0.5f, -0.5f,  1.0f, 1.0f,
		-0.25f, -0.5f, -0.5f,  0.0f, 1.0f,
		-0.25f, -0.5f, -0.5f,  0.0f, 1.0f,
		-0.25f, -0.5f,  0.5f,  0.0f, 0.0f,
		-0.25f,  0.5f,  0.5f,  1.0f, 0.0f,

		//cube one right
		 0.75f,  0.5f,  0.5f,  1.0f, 0.0f,
		 0.75f,  0.5f, -0.5f,  1.0f, 1.0f,
		 0.75f, -0.5f, -0.5f,  0.0f, 1.0f,
		 0.75f, -0.5f, -0.5f,  0.0f, 1.0f,
		 0.75f, -0.5f,  0.5f,  0.0f, 0.0f,
		 0.75f,  0.5f,  0.5f,  1.0f, 0.0f,

		//cube one bottom
		-0.25f, -0.5f, -0.5f,  0.0f, 1.0f,
		 0.75f, -0.5f, -0.5f,  1.0f, 1.0f,
		 0.75f, -0.5f,  0.5f,  1.0f, 0.0f,
		 0.75f, -0.5f,  0.5f,  1.0f, 0.0f,
		-0.25f, -0.5f,  0.5f,  0.0f, 0.0f,
		-0.25f, -0.5f, -0.5f,  0.0f, 1.0f,

		// cube one top
		-0.25f,  0.5f, -0.5f,  0.0f, 1.0f,
		 0.75f,  0.5f, -0.5f,  1.0f, 1.0f,
		 0.75f,  0.5f,  0.5f,  1.0f, 0.0f,
		 0.75f,  0.5f,  0.5f,  1.0f, 0.0f,
		-0.25f,  0.5f,  0.5f,  0.0f, 0.0f,
		-0.25f,  0.5f, -0.5f,  0.0f, 1.0f,

		//cube two back
		-0.5f, -1.5f, -0.5f,  0.0f, 0.0f,
		 0.5f, -1.5f, -0.5f,  1.0f, 0.0f,
		 0.5f,  -0.5f, -0.5f,  1.0f, 1.0f,
		 0.5f,  -0.5f, -0.5f,  1.0f, 1.0f,
		-0.5f,  -0.5f, -0.5f,  0.0f, 1.0f,
		-0.5f, -1.5f, -0.5f,  0.0f, 0.0f,

		//cube two front
		-0.5f, -1.5f,  0.5f,  0.0f, 0.0f,
		 0.5f, -1.5f,  0.5f,  1.0f, 0.0f,
		 0.5f,  -0.5f,  0.5f,  1.0f, 1.0f,
		 0.5f,  -0.5f,  0.5f,  1.0f, 1.0f,
		-0.5f,  -0.5f,  0.5f,  0.0f, 1.0f,
		-0.5f, -1.5f,  0.5f,  0.0f, 0.0f,

		//cube two left
		-0.5f,  -0.5f,  0.5f,  1.0f, 0.0f,
		-0.5f,  -0.5f, -0.5f,  1.0f, 1.0f,
		-0.5f, -1.5f, -0.5f,  0.0f, 1.0f,
		-0.5f, -1.5f, -0.5f,  0.0f, 1.0f,
		-0.5f, -1.5f,  0.5f,  0.0f, 0.0f,
		-0.5f,  -0.5f,  0.5f,  1.0f, 0.0f,

		//cube two right
		 0.5f,  -0.5f,  0.5f,  1.0f, 0.0f,
		 0.5f,  -0.5f, -0.5f,  1.0f, 1.0f,
		 0.5f, -1.5f, -0.5f,  0.0f, 1.0f,
		 0.5f, -1.5f, -0.5f,  0.0f, 1.0f,
		 0.5f, -1.5f,  0.5f,  0.0f, 0.0f,
		 0.5f,  -0.5f,  0.5f,  1.0f, 0.0f,

		// cube two bottom
		-0.5f,  -1.5f, -0.5f,  0.0f, 1.0f,
		 0.5f,  -1.5f, -0.5f,  1.0f, 1.0f,
		 0.5f,  -1.5f,  0.5f,  1.0f, 0.0f,
		 0.5f,  -1.5f,  0.5f,  1.0f, 0.0f,
		-0.5f,  -1.5f,  0.5f,  0.0f, 0.0f,
		-0.5f,  -1.5f, -0.5f,  0.0f, 1.0f,

		// cube two top
		-0.5f,  -0.5f, -0.5f,  0.0f, 1.0f,
		 0.5f,  -0.5f, -0.5f,  1.0f, 1.0f,
		 0.5f,  -0.5f,  0.5f,  1.0f, 0.0f,
		 0.5f,  -0.5f,  0.5f,  1.0f, 0.0f,
		-0.5f,  -0.5f,  0.5f,  0.0f, 0.0f,
		-0.5f,  -0.5f, -0.5f,  0.0f, 1.0f,

			//cube three back
		 5.0f, -1.5f, -4.0f, 0.0f, 0.0f,
		 9.0f, -1.5f, -4.0f, 1.0f, 0.0f,
		 9.0f, -0.5f, -4.0f, 1.0f, 1.0f,
	   	 9.0f, -0.5f, -4.0f, 1.0f, 1.0f,
    	 5.0f, -0.5f, -4.0f, 0.0f, 1.0f,
		 5.0f, -1.5f, -4.0f, 0.0f, 0.0f,

		 //cube three front
		 5.0f, -1.5f, -1.0f, 0.0f, 0.0f,
	   	 9.0f, -1.5f, -1.0f, 1.0f, 0.0f,
		 9.0f, -0.5f, -1.0f, 1.0f, 1.0f,
		 9.0f, -0.5f, -1.0f, 1.0f, 1.0f,
		 5.0f, -0.5f, -1.0f, 0.0f, 1.0f,
		 5.0f, -1.5f, -1.0f, 0.0f, 0.0f,

		 //cube three left
		 5.0f, -0.5f, -1.0f, 1.0f, 0.0f,
		 5.0f, -0.5f, -4.0f, 1.0f, 1.0f,
		 5.0f, -1.5f, -4.0f, 0.0f, 1.0f,
		 5.0f, -1.5f, -4.0f, 0.0f, 1.0f,
		 5.0f, -1.5f, -1.0f, 0.0f, 0.0f,
		 5.0f, -0.5f, -1.0f, 1.0f, 0.0f,

		 //cube two right
		  9.0f, -0.5f, -1.0f, 1.0f, 0.0f,
		  9.0f, -0.5f, -4.0f, 1.0f, 1.0f,
		  9.0f, -1.5f, -4.0f, 0.0f, 1.0f,
		  9.0f, -1.5f, -4.0f, 0.0f, 1.0f,
		  9.0f, -1.5f, -1.0f, 0.0f, 0.0f,
		  9.0f, -0.5f, -1.0f, 1.0f, 0.0f,

		 // cube two bottom
		 5.0f, -1.5f, -1.0f, 0.0f, 1.0f,
		 9.0f, -1.5f, -1.0f, 1.0f, 1.0f,
		 9.0f, -1.5f, -4.0f, 1.0f, 0.0f,
		 9.0f, -1.5f, -4.0f, 1.0f, 0.0f,
		 5.0f, -1.5f, -4.0f, 0.0f, 0.0f,
		 5.0f, -1.5f, -1.0f, 0.0f, 1.0f,

		 // cube three top
		  5.0f, -0.5f, -1.0f, 0.0f, 1.0f,
		  9.0f, -0.5f, -1.0f, 1.0f, 1.0f,
		  9.0f, -0.5f, -4.0f, 1.0f, 0.0f,
		  9.0f, -0.5f, -4.0f, 1.0f, 0.0f,
		  5.0f, -0.5f, -4.0f, 0.0f, 0.0f,
		  5.0f, -0.5f, -1.0f, 0.0f, 1.0f,
	};


	unsigned int VBO, VAO;
	unsigned int VBO2, VAO2;

	glGenVertexArrays(1, &VAO);
	glGenBuffers(1, &VBO);
	glBindVertexArray(VAO);
	glBindBuffer(GL_ARRAY_BUFFER, VBO);
	glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);


	// position attribute
	glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)0);
	glEnableVertexAttribArray(0);
	// texture coord attribute
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 5 * sizeof(float), (void*)(3 * sizeof(float)));
	glEnableVertexAttribArray(1);


	glGenVertexArrays(1, &VAO2);
	glGenBuffers(1, &VBO2);
	glBindVertexArray(VAO2);
	glBindBuffer(GL_ARRAY_BUFFER, VBO2);

	// load and create a texture 
	// -------------------------
	unsigned int texture1, texture2, texture3;
	// texture 1
	// ---------
	glGenTextures(1, &texture1);
	glBindTexture(GL_TEXTURE_2D, texture1);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	int width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char* data = stbi_load("images/container.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);
	// texture 2
	// ---------
	glGenTextures(1, &texture2);
	glBindTexture(GL_TEXTURE_2D, texture2);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	data = stbi_load("images/awesomeface.png", &width, &height, &nrChannels, 0);
	if (data)
	{
		// note that the awesomeface.png has transparency and thus an alpha channel, so make sure to tell OpenGL the data type is of GL_RGBA
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data);

	// texture 3
// ---------
	glGenTextures(1, &texture3);
	glBindTexture(GL_TEXTURE_2D, texture3);
	// set the texture wrapping parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	// set texture filtering parameters
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	// load image, create texture and generate mipmaps
	width, height, nrChannels;
	stbi_set_flip_vertically_on_load(true); // tell stb_image.h to flip loaded texture's on the y-axis.
	unsigned char* data2 = stbi_load("images/brick.jpg", &width, &height, &nrChannels, 0);
	if (data)
	{
		glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, data2);
		glGenerateMipmap(GL_TEXTURE_2D);
	}
	else
	{
		std::cout << "Failed to load texture" << std::endl;
	}
	stbi_image_free(data2);

	// tell opengl for each sampler to which texture unit it belongs to (only has to be done once)
	// -------------------------------------------------------------------------------------------
	ourShader.use();
	ourShader.setInt("texture1", 0);
	ourShader.setInt("texture2", 1);
	ourShader.setInt("texture3", 2);

	glm::mat4 model;
	float angle;

	Sphere S(0.4, 30, 30);
	float sphere_angle = 0;
	// render loop
	// -----------
	while (!glfwWindowShouldClose(window))
	{

		// per-frame time logic
		// --------------------
		float currentFrame = glfwGetTime();
		deltaTime = currentFrame - lastFrame;
		lastFrame = currentFrame;

		// input
		// -----
		processInput(window);

		// render
		// ------
		glClearColor(0.2f, 0.3f, 0.3f, 1.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture1);
		//glActiveTexture(GL_TEXTURE1);
		//glBindTexture(GL_TEXTURE_2D, texture2);

		// activate shader
		ourShader.use();

		// pass projection matrix to shader (note that in this case it could change every frame)
		glm::mat4 projection = glm::perspective(glm::radians(fov), (float)SCR_WIDTH / (float)SCR_HEIGHT, 0.1f, 100.0f);
		ourShader.setMat4("projection", projection);

		// camera/view transformation
		glm::mat4 view = glm::lookAt(cameraPos, cameraPos + cameraFront, cameraUp);
		ourShader.setMat4("view", view);

		// render boxes
		glBindVertexArray(VAO);
		// calculate the model matrix for each object and pass it to shader before drawing
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(0.0f, 1.0f, 0.0f));
		angle = 0.0f;
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));
		ourShader.setMat4("model", model);


		glDrawArrays(GL_TRIANGLES, 0, 114);

		//cylinder
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, 0.0f, -4.0f));
		ourShader.setMat4("model", model);

		//size of cylinder
		static_meshes_3D::Cylinder C(1.5, 1000, 1, true, true, true);
		C.render();

		//cylinder 2
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, 0.5f, -4.0f));
		ourShader.setMat4("model", model);

		//size of cylinder 2 
		static_meshes_3D::Cylinder C2(1.3, 1000, 1, true, true, true);
		C2.render();
		
		//cylinder 3
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, 1.0f, -4.0f));
		ourShader.setMat4("model", model);

		//size of cylinder  3
		static_meshes_3D::Cylinder C3(1.1, 1000, 1, true, true, true);
		C3.render();

		//cylinder 4
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, 1.8f, -4.0f));
		ourShader.setMat4("model", model);

		//size of cylinder  4
		static_meshes_3D::Cylinder C4(0.5, 1000, 1, true, true, true);
		C4.render();

		//cylinder 5
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, 2.0f, -4.0f));
		ourShader.setMat4("model", model);

		//size of cylinder  5
		static_meshes_3D::Cylinder C5(0.3, 1000, 1, true, true, true);
		C5.render();

		//cylinder 6
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, 2.1f, -4.0f));
		ourShader.setMat4("model", model);

		//size of cylinder  6
		static_meshes_3D::Cylinder C6(0.1, 1000, 1, true, true, true);
		C6.render();


		//location of sphere
		glActiveTexture(GL_TEXTURE0);
		glBindTexture(GL_TEXTURE_2D, texture2);
		glBindVertexArray(VAO2);
		model = glm::mat4(1.0f); // make sure to initialize matrix to identity matrix first		
		model = glm::translate(model, glm::vec3(2.5f, -0.09f, 2.5f));
		model = glm::rotate(model, glm::radians(angle), glm::vec3(1.0f, 0.3f, 0.5f));

		ourShader.setMat4("model", model);


		

		S.Draw();

		// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
		// -------------------------------------------------------------------------------
		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	// optional: de-allocate all resources once they've outlived their purpose:
	// ------------------------------------------------------------------------
	glDeleteVertexArrays(1, &VAO);
	glDeleteBuffers(1, &VBO);

	glDeleteVertexArrays(1, &VAO2);
	glDeleteBuffers(1, &VBO2);

	// glfw: terminate, clearing all previously allocated GLFW resources.
	// ------------------------------------------------------------------
	glfwTerminate();
	return 0;
}

// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
// ---------------------------------------------------------------------------------------------------------
void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	float cameraSpeed = 2.5 * deltaTime;
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
		cameraPos += cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
		cameraPos -= cameraSpeed * cameraFront;
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
		cameraPos -= glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
		cameraPos += glm::normalize(glm::cross(cameraFront, cameraUp)) * cameraSpeed;


}


// glfw: whenever the window size changed (by OS or user resize) this callback function executes
// ---------------------------------------------------------------------------------------------
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and 
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void mouse_callback(GLFWwindow* window, double xpos, double ypos)
{
	if (firstMouse)
	{
		lastX = xpos;
		lastY = ypos;
		firstMouse = false;
	}

	float xoffset = xpos - lastX;
	float yoffset = lastY - ypos; // reversed since y-coordinates go from bottom to top
	lastX = xpos;
	lastY = ypos;

	float sensitivity = 0.1f; // change this value to your liking
	xoffset *= sensitivity;
	yoffset *= sensitivity;

	yaw += xoffset;
	pitch += yoffset;

	// make sure that when pitch is out of bounds, screen doesn't get flipped
	if (pitch > 89.0f)
		pitch = 89.0f;
	if (pitch < -89.0f)
		pitch = -89.0f;

	glm::vec3 front;
	front.x = cos(glm::radians(yaw)) * cos(glm::radians(pitch));
	front.y = sin(glm::radians(pitch));
	front.z = sin(glm::radians(yaw)) * cos(glm::radians(pitch));
	cameraFront = glm::normalize(front);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void scroll_callback(GLFWwindow* window, double xoffset, double yoffset)
{
	fov -= (float)yoffset;
	if (fov < 1.0f)
		fov = 1.0f;
	if (fov > 45.0f)
		fov = 45.0f;
}